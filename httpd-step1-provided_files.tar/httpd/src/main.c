#include "config/config.h"

int main(void)
{
    return 0;
}
