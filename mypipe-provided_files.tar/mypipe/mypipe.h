#ifndef MYPIPE_H
#define MYPIPE_H

int exec_pipe(char **argv_left, char **argv_right);

#endif /* ! MYPIPE_H */
